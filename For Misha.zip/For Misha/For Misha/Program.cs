﻿Console.WriteLine("Do you love me???");
Console.WriteLine("yes or no");
string yes = Console.ReadLine();
if (yes == "yes") Console.WriteLine("I LOVE YOU TOO <3");
if (yes == "no") Console.WriteLine("I still love you");
if (yes != "no" && yes != "yes") Console.WriteLine("Try again :)");